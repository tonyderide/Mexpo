export class Musee {
idMusee: string;
nomMusee: string;
adresse: string;
ville: string;
siteWeb: string;
geolocalisation: string;
description: string;
}
