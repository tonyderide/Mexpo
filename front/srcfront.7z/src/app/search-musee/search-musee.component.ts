import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-musee',
  templateUrl: './search-musee.component.html',
  styleUrls: ['./search-musee.component.scss']
})
export class SearchMuseeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
